module.exports=[41296,(e,o,d)=>{}];

//# sourceMappingURL=80b94_GBPRO_fe_live__next-internal_server_app_favicon_ico_route_actions_3f27bc73.js.map