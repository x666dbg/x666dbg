module.exports=[30111,(e,o,d)=>{}];

//# sourceMappingURL=80b94_GBPRO_fe_live__next-internal_server_app_sitemap_xml_route_actions_71c14a4e.js.map