module.exports=[52264,(a,b,c)=>{}];

//# sourceMappingURL=Documents_GBPRO_fe_live__next-internal_server_app_page_actions_8348834c.js.map