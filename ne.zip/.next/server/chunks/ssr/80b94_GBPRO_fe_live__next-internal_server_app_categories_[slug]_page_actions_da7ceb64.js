module.exports=[7799,(a,b,c)=>{}];

//# sourceMappingURL=80b94_GBPRO_fe_live__next-internal_server_app_categories_%5Bslug%5D_page_actions_da7ceb64.js.map