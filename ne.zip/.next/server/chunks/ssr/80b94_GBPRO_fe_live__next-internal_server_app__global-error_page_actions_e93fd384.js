module.exports=[33173,(a,b,c)=>{}];

//# sourceMappingURL=80b94_GBPRO_fe_live__next-internal_server_app__global-error_page_actions_e93fd384.js.map