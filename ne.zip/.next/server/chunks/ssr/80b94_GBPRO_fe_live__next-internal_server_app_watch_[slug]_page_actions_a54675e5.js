module.exports=[89651,(a,b,c)=>{}];

//# sourceMappingURL=80b94_GBPRO_fe_live__next-internal_server_app_watch_%5Bslug%5D_page_actions_a54675e5.js.map