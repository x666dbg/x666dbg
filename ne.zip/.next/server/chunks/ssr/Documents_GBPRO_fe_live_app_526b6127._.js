module.exports=[80516,a=>{a.v("/_next/static/media/favicon.ad9f9883.ico")},45649,a=>{"use strict";let b={src:a.i(80516).default,width:1024,height:1024};a.s(["default",0,b])}];

//# sourceMappingURL=Documents_GBPRO_fe_live_app_526b6127._.js.map