module.exports=[95302,(a,b,c)=>{}];

//# sourceMappingURL=Documents_GBPRO_fe_live__next-internal_server_app_trending_page_actions_584e6759.js.map