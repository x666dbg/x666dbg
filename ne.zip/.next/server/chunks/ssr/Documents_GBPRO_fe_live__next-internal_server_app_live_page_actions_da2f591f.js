module.exports=[2181,(a,b,c)=>{}];

//# sourceMappingURL=Documents_GBPRO_fe_live__next-internal_server_app_live_page_actions_da2f591f.js.map