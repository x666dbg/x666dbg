module.exports=[34654,(a,b,c)=>{}];

//# sourceMappingURL=Documents_GBPRO_fe_live__next-internal_server_app_dmca_page_actions_81809a5e.js.map