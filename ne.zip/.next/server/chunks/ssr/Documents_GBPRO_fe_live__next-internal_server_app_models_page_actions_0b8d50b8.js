module.exports=[71436,(a,b,c)=>{}];

//# sourceMappingURL=Documents_GBPRO_fe_live__next-internal_server_app_models_page_actions_0b8d50b8.js.map