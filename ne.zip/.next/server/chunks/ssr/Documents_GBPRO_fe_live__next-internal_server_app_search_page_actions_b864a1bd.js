module.exports=[55152,(a,b,c)=>{}];

//# sourceMappingURL=Documents_GBPRO_fe_live__next-internal_server_app_search_page_actions_b864a1bd.js.map