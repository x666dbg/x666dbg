module.exports=[42601,(a,b,c)=>{}];

//# sourceMappingURL=Documents_GBPRO_fe_live__next-internal_server_app_privacy_page_actions_eb4e76fa.js.map