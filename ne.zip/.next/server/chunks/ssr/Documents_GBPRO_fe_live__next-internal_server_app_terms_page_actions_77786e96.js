module.exports=[39456,(a,b,c)=>{}];

//# sourceMappingURL=Documents_GBPRO_fe_live__next-internal_server_app_terms_page_actions_77786e96.js.map