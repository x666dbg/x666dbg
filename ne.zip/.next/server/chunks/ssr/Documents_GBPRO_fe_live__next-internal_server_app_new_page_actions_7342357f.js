module.exports=[9733,(a,b,c)=>{}];

//# sourceMappingURL=Documents_GBPRO_fe_live__next-internal_server_app_new_page_actions_7342357f.js.map