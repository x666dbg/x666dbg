module.exports=[69452,(a,b,c)=>{}];

//# sourceMappingURL=80b94_GBPRO_fe_live__next-internal_server_app_disclaimer_page_actions_6896d02c.js.map