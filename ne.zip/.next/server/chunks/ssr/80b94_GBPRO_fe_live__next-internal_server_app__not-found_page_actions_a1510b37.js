module.exports=[62151,(a,b,c)=>{}];

//# sourceMappingURL=80b94_GBPRO_fe_live__next-internal_server_app__not-found_page_actions_a1510b37.js.map