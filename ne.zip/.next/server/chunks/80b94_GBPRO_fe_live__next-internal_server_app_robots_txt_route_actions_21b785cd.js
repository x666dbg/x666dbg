module.exports=[90223,(e,o,d)=>{}];

//# sourceMappingURL=80b94_GBPRO_fe_live__next-internal_server_app_robots_txt_route_actions_21b785cd.js.map