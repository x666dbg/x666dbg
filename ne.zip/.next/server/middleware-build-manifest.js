globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/d7e03e22ec300904.js",
    "static/chunks/ec6f24db1f661387.js",
    "static/chunks/ddfb588b0aa06f11.js",
    "static/chunks/b6f2b48b440ed944.js",
    "static/chunks/turbopack-1c053c920181503d.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];