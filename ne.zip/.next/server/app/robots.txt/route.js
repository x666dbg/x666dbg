var R=require("../../chunks/[turbopack]_runtime.js")("server/app/robots.txt/route.js")
R.c("server/chunks/[root-of-the-server]__5e9d4578._.js")
R.c("server/chunks/[root-of-the-server]__6476e9df._.js")
R.c("server/chunks/80b94_GBPRO_fe_live__next-internal_server_app_robots_txt_route_actions_21b785cd.js")
R.m(55284)
module.exports=R.m(55284).exports
