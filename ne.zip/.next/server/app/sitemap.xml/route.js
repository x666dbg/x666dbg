var R=require("../../chunks/[turbopack]_runtime.js")("server/app/sitemap.xml/route.js")
R.c("server/chunks/[root-of-the-server]__034dd176._.js")
R.c("server/chunks/[root-of-the-server]__6476e9df._.js")
R.c("server/chunks/80b94_GBPRO_fe_live__next-internal_server_app_sitemap_xml_route_actions_71c14a4e.js")
R.m(76071)
module.exports=R.m(76071).exports
